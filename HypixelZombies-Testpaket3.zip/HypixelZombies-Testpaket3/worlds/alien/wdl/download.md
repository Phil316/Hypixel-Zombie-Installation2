# Download report: Minecraft‐Server

<img src="../icon.png" alt="Server icon">

- **Finished**: 2026-11-06 18:13 (MEZ) | 2026-11-06 17:13:31 UTC | epoch 1793985211
- **Downloaded by**: Phil\_316
- **Duration**: 0m 27s
- **Status**: Completed cleanly

## Server
- **Address**: mc.hypixel.net
- **MOTD**: Hypixel Network \[1.8/26.3\] SKYBLOCK GHOST VISITORS
- **Server software**: Hypixel BungeeCord (2026.11.3.1) \<- Hygot 2026.11.3.1
- **Simulation distance**: 32 chunks

## Summary
- **Dimensions**: 1
  - `minecraft:overworld` (506 chunks)
- **Chunks**: 506
- **Entities**: 135
- **Containers**: 0

## Software
- **Archive World Downloader**: 1.3.0+1.21.11
- **Minecraft**: 1.21.11
- **Loader**: Fabric 0.19.5

## Settings at download time
- Defaults

---
*Made with [Archive World Downloader](https://github.com/thearchive-world/archive-world-downloader).*
